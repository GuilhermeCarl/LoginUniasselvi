package dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import principal.Config;

public abstract class Conexao extends Config 
{

	public java.sql.Connection conn;
	public java.sql.Statement  stmt;
	
	protected void desconecta() 
	{
		try {
			if(stmt!=null) {
				stmt.close();
				conn.close();
			}
		}
		catch(SQLException se){
			se.printStackTrace();
		}
	}
	
	protected boolean conecta() 
	{
		boolean retorno = false;
		try {
			Class.forName( JDBC_DRIVER );
			conn = DriverManager.getConnection(BANCO+BASE, USER, PASS);
			stmt = conn.createStatement();
			// System.out.println("Conexao->Conexao() OK! ");
			retorno = true;
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			System.out.println("Conexao->Conexao() Erro: "+e.getMessage() );
			
		}
		return retorno;
	}
	
    
    /**
     * Executa um Insert<br>
     * @param String SQL
     * @return int o código do último registro adicionado
     */
	protected int inserir(String sql)
    {
    	int cod = 0;
    	if ( this.conecta() ) {
			try {
				this.stmt.executeUpdate(sql);
				ResultSet rs = (ResultSet) this.stmt.executeQuery("SELECT LAST_INSERT_ID()");
				if (rs.next()) {
			        cod = rs.getInt(1);
				}
			} catch (SQLException e) {
				System.out.println("Conexao->insert() Erro"+e.getMessage());
				// e.printStackTrace();
			}
			this.desconecta();
    	}
    	return cod;
    }
    
    /**
     * Executa um Update ou um Delete<br>
     * @param String SQL
     * @return int número de registros afettados
     */
	protected int comando(String sql)
    {
    	int qtd = 0;
    	if ( this.conecta() ) {
			try {
				qtd = this.stmt.executeUpdate(sql);
			} catch (SQLException e) {
				System.out.println("Conexao->comando() Erro: "+e.getMessage());
				// e.printStackTrace();
			}
			this.desconecta();
    	}
    	return qtd;
    }
}
