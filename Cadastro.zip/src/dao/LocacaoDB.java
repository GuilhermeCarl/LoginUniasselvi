package dao;

import java.util.ArrayList;

public interface LocacaoDB {

	public ArrayList<Object> listar ( String where );
	public int               insert ( Object obj   );
	public int               salvar ( Object obj   );
	public boolean           excluir( Object obj   );
	
}
