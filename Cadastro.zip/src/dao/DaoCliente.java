package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entidades.Usuario;

public class DaoCliente extends Conexao implements LocacaoDB 
{
	public DaoCliente( ) {
		super();
	}

	@Override
	public ArrayList<Object> listar( String where ) 
	{
		// System.out.println("Usuario.getLista() where: "+where);
		ArrayList<Object> lista = new ArrayList<Object>();
		String sql = "SELECT * FROM "+Usuario.TB_USUARIO+"  WHERE 1 = 1 "+where;
		// System.out.println("Usuario.listar() sql: "+sql);
		ResultSet res = null;
    	if ( this.conecta() ) {
			try {
				res = (ResultSet) this.stmt.executeQuery(""+sql+"");
				while(res.next()) {
					Usuario us = new Usuario();
		 			us.setCodusu( Integer.toString(res.getInt(Usuario.US_CODUSU)) );
					us.setNomusu(res.getString(Usuario.US_NOMUSU));
					us.setEmausu(res.getString(Usuario.US_EMAUSU));
					lista.add(us);
				}
				this.desconecta();
			} 
			catch (SQLException e) {
				System.out.println("Usuario.getLista() Erro: "+e.getMessage());
			}
			this.desconecta();
    	}
		return lista;
	}

	@Override
    public int insert( Object obj )
    {
    	Usuario us = (Usuario) obj;
    	String sql = "INSERT INTO tb_usuario(       us_nomusu     ,       us_emausu      )"
    			                  + " VALUES( '"+us.getNomusu()+"', '"+us.getEmausu()+"' )" ;
    	// System.out.println("Usuario.insert() sql: "+sql);
		return this.inserir(sql);
    }
    
	@Override
	public int salvar (Object obj ) {
		Usuario us = (Usuario) obj;
		String sql = "UPDATE tb_usuario SET us_nomusu = '"+us.getNomusu()+"', us_emausu = '"+us.getEmausu()+"' WHERE us_codusu = "+us.getCodusu()+"; ";
		// System.out.println("Usuario.salvar() sql: "+sql);
		return this.comando(sql);
	}

	@Override
	public boolean excluir( Object obj ) {
		 Usuario us = (Usuario) obj;
		 String sql = "DELETE FROM tb_usuario WHERE us_codusu = "+us.getCodusu()+"; ";
		 // System.out.println("Usuario.excluir() sql: "+sql);
		return this.comando(sql)>0;
	}
	
}
