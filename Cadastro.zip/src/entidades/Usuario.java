package entidades;

public class Usuario {

	public static final String SQL_CREATE 
		= " CREATE TABLE tb_usuario ( "
	    + "	  us_codusu int(11) NOT NULL AUTO_INCREMENT,"
	    + "   us_nomusu varchar(100) NOT NULL,"
	    + "   us_emausu varchar(100) NOT NULL,"
	    + "   PRIMARY KEY (us_codusu)  ) " ;

	public static final String SQL_CREATE_OPCIONAL 
		= " INSERT INTO tb_usuario ( us_nomusu, us_emausu ) "
        + " VALUES ( 'Usuário 1', 'email1@teste.com' )"
        + "      , ( 'Usuário 2', 'email2@teste.com' )"
        + "      , ( 'Usuário 3', 'email3@teste.com' )"
        + "      , ( 'Usuário 4', 'email4@teste.com' ) ";
	
	public static final String TB_USUARIO = "tb_usuario";
	/** Código sequencial do usuário */
	public static final String US_CODUSU  = "us_codusu";
	public static final String US_NOMUSU  = "us_nomusu";
	public static final String US_EMAUSU  = "us_emausu";
	
	private String codusu = "";
	private String nomusu = "";
	private String emausu = "";
	
	public Usuario() {
		this.setCodusu("0");
		this.setNomusu("");
		this.setEmausu("");
	}
	public Usuario( String nom, String ema ) {
		this.setCodusu("0");
		this.setNomusu(nom);
		this.setEmausu(ema);
	}
	public Usuario( String cod, String nom, String ema ) {
		this.setCodusu(cod);
		this.setNomusu(nom);
		this.setEmausu(ema);
	}
	
	public String getCodusu() {
		return codusu;
	}
	public void setCodusu(String codusu) {
		this.codusu = codusu;
	}
	public void setCodusu(Integer codusu) {
		this.codusu = Integer.toString(codusu);
	}
	public String getNomusu() {
		return nomusu;
	}
	public void setNomusu(String nomusu) {
		this.nomusu = nomusu;
	}
	public String getEmausu() {
		return emausu;
	}
	public void setEmausu(String emausu) {
		this.emausu = emausu;
	}
	
	
}
