package principal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Leitor 
{

	public static float lerFloat() 
	{
		float retorno = 0;
		boolean ok = false;
		BufferedReader leitor = new BufferedReader(new InputStreamReader( System.in ));
		String str_digitada = "";
		do {
			try {
				str_digitada = leitor.readLine();
				retorno = Float.parseFloat( str_digitada );
				System.out.println("");
				ok = true;
			} 
			catch ( NumberFormatException | IOException e ) {
				System.out.print("Digite um número válido (0.00): ");
			}
			
		} while ( ! ok );
		
		return retorno;
	}
	
	public static int lerInt() 
	{
		int retorno = 0;
		boolean ok = false;
		BufferedReader leitor = new BufferedReader(new InputStreamReader( System.in ));
		String str_digitada = "";
		do {
			try {
				str_digitada = leitor.readLine();
				retorno = Integer.parseInt( str_digitada );
				System.out.println("");
				ok = true;
			} 
			catch ( NumberFormatException | IOException e) {
				System.out.print("Digite um número válido: ");
			}
			
		} while ( ! ok );
		
		return retorno;
	}
	
	public static String lerTexto() 
	{
		BufferedReader leitor = new BufferedReader(new InputStreamReader( System.in ));
		String str_digitada = "";
		try {
			str_digitada = leitor.readLine();
			System.out.println("");
		} 
		catch (IOException e) {
			System.out.print("Digite uma string válida: ");
		}

		return str_digitada;
	}
	
}
