package principal;

import java.io.IOException;
import java.util.ArrayList;

import dao.DaoCliente;
import entidades.Usuario;

public class Sistema 
{
	public static void Leitor(String[] args) throws IOException 
	{
		//DaoCliente d_us = new DaoCliente();
		//Usuario   en_us = new Usuario("Marcelo Fey", "teste@email.com" );
		//System.out.println("Usuário criado = "+d_us.insert(en_us));
		int opcao_selecionada;
		do {
			opcao_selecionada = menu_Leitor();
			switch ( opcao_selecionada ) 
			{
				case 1:{
					int opcao_selecionada_usuario;
					do {
						opcao_selecionada_usuario = menu_usuario();	
					} while ( opcao_selecionada_usuario > 0 );
				    break;
				}
				default:{
					System.out.println("Digite uma opção válida! ");
					break;
				}
			}
			
			
		} while ( opcao_selecionada > 0 );
			
		System.out.println("\n * * Programa FINALIZADO! * * \n ");
		
	}
	public static int menu_Leitor() 
	{
		System.out.println("\n");
		System.out.println("* * * * * * * * * * * * * * * ");
		System.out.println("*     Menu Principal        * ");
		System.out.println("* * * * * * * * * * * * * * * ");
		System.out.println(" -> 1 Usuários.");
		System.out.println(" -> 2 ...");
		System.out.println(" -> 3 ...");
		System.out.println(" -> 0 Sair e finalizar programa.");
		System.out.print  ("  ? ");
		return Leitor.lerInt(); 
	}
	public static int menu_usuario() 
	{
		System.out.println("\n");
		System.out.println("* * * * * * * * * * * * * * * ");
		System.out.println("*      Menu Usuários        * ");
		System.out.println("* * * * * * * * * * * * * * * ");
		System.out.println(" -> 1 Listar.");
		System.out.println(" -> 2 Novo.");
		System.out.println(" -> 0 Voltar ao Menu Principal.");
		System.out.print  ("  ? ");
		int opcao_selecionada = Leitor.lerInt();
		switch ( opcao_selecionada ) 
		{
			case 1: 
			{
				System.out.println("\nLista de Usuários: ");
				DaoCliente d_us = new DaoCliente();
				// ArrayList<Object> lista_de_usuarios =  d_us.listar( " AND "+Usuario.US_NOMUSU+" LIKE '%Y%' OR "+Usuario.US_CODUSU+" > 3 ORDER BY 1 DESC " );
				ArrayList<Object> lista_de_usuarios =  d_us.listar( "" );
				for ( int i = 0; i < lista_de_usuarios.size(); i++ ) {
					Usuario us = (Usuario) lista_de_usuarios.get(i);
					System.out.println("["+ us.getCodusu()+"] "+ us.getNomusu()+"\t"+ us.getEmausu()+" " );
				}
				System.out.println("\nDigite o Código para selecionar ou 0(zero) para voltar ao menu anterior: ");
				System.out.print("  ? ");
				int codigo_selecionado = Leitor.lerInt();
				Usuario us_selecionado = new Usuario();
				if ( codigo_selecionado > 0 ) 
				{
					for ( int i = 0; i < lista_de_usuarios.size(); i++ ) {
						Usuario us_lista = (Usuario) lista_de_usuarios.get(i);
						if ( codigo_selecionado == Integer.parseInt(us_lista.getCodusu()) ) {
							us_selecionado = us_lista;
						}
					}
					if ( Integer.parseInt(us_selecionado.getCodusu()) > 0  ) 
					{
						System.out.println("\nOk! Usuário["+us_selecionado.getCodusu()+": "+us_selecionado.getNomusu()+"] selecionado, [1] Editar, [2] Excluir, [0] Voltar.");
						System.out.print("  ? ");
						int opcao_selecionado = Leitor.lerInt();
						if ( opcao_selecionado == 1 ) 
						{
							System.out.println(" * Editar Usuário código ["+us_selecionado.getCodusu()+": "+us_selecionado.getNomusu()+"] ");
							System.out.println(" -> Informe o novo Nome ou 'Vazio' para permanecer ("+us_selecionado.getNomusu()+")");
							System.out.print("  ? ");
							String nome = Leitor.lerTexto();
							if ( nome.length() > 0 ) {
								us_selecionado.setNomusu(nome);
							}
							System.out.println(" -> Informe o Email Nome ou vazio para permanecer ("+us_selecionado.getEmausu()+")");
							System.out.print("  ? ");
							String email = Leitor.lerTexto();
							if( email.length() > 0 ) {
								us_selecionado.setEmausu(email);
							}
							
							if ( d_us.salvar( us_selecionado ) > 0 ) {
								System.out.println("Usuário alterado com sucesso! :) \n\n");
							}
							else {
								System.out.println("Usuário não foi alterado! :( \n\n");
							}
						}
						else if ( opcao_selecionado == 2 ) 
						{
							System.out.print(" * Deseja mesmo excluir o Usuário["+codigo_selecionado+"]? [ S / N ] : ");
							if ( Leitor.lerTexto().equalsIgnoreCase("S") ) {
								if ( d_us.excluir( us_selecionado ) ){
									System.out.println("Usuário excluído com sucesso! :) \n\n");
								}
								else {
									System.out.println("Usuário não foi excluído! :( \n\n");
								}
							}
						}
					}
					else {
						System.out.println("Usuário não encontrado!");
					}
				} // FIM if ( codigo_selecionado > 0 ) 
				break;
			} // FIM case 1: 
			case 2: 
			{
				System.out.println("\nNovo usuário: Informe 'X' para cancelar. ");
				DaoCliente d_us = new DaoCliente();
				Usuario    e_us = new Usuario();
				String     nome = "";
				do {
					System.out.println("Informe o Nome: (Obrigatório) ");
					nome = Leitor.lerTexto();
					e_us.setNomusu(nome);
				} while ( nome.length() <= 0 ); 
				
				if ( ! e_us.getNomusu().equalsIgnoreCase("x") ) 
				{
					System.out.println("Informe o Email: (opcional) ");
					e_us.setEmausu(Leitor.lerTexto());
					
					e_us.setCodusu( d_us.insert(e_us));
					if ( Integer.parseInt(e_us.getCodusu()) > 0 ) {
						System.out.println("Usuário inserido com sucesso! :) \n\n");
					}
					else {
						System.out.println("Usuário não foi inserido! :( \n\n");
					}
				}
				else 
				{
					System.out.println("Novo usuário Cancelado!");
				}
				break;
			} // FIM case 2: 
		}
		return opcao_selecionada;
	}
	
}
