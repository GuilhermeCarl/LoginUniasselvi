package principal;

import java.sql.DriverManager;
import java.sql.SQLException;

import entidades.Usuario;

public class Install extends Config {

	public static void main(String[] args)
	{  
		System.out.println("Install.main() ");
		if ( Install.verifica_se_base_existe() ) {
			System.out.println("Install.main() Ok, Base ("+BASE+") já existe.");
		}
		else 
		{
			System.out.println("Install.main() Base ("+BASE+") ainda não existe.");
			try 
			{
				Class.forName( JDBC_DRIVER );
				java.sql.Connection conn = DriverManager.getConnection(BANCO, USER, PASS);
				java.sql.Statement  stmt = conn.createStatement();

				stmt.executeUpdate("CREATE DATABASE "+BASE);
				System.out.println("Base ("+BASE+") criada com sucesso.");
				stmt.close(); 
				conn.close();
				
				conn = DriverManager.getConnection(BANCO+BASE, USER, PASS);
				stmt = conn.createStatement();
				
				stmt.executeUpdate(Usuario.SQL_CREATE); 
				stmt.executeUpdate(Usuario.SQL_CREATE_OPCIONAL);
				
				stmt.close(); conn.close(); 
				
			} 
			catch (SQLException | ClassNotFoundException e) 
			{
				System.out.println("Install.main() Erro: "+e.getMessage() );
			}

		}
	}
	
	public static boolean verifica_se_base_existe() 
	{
		boolean retorno = false;
		
		try 
		{
			Class.forName( JDBC_DRIVER );
			java.sql.Connection conn = DriverManager.getConnection(BANCO, USER, PASS);
			java.sql.Statement  stmt = conn.createStatement();
			java.sql.ResultSet  res  = stmt.executeQuery( 
					" SELECT COUNT(1) AS qtd FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = '"+BASE+"' ;");
			res.first();
			retorno = res.getInt("qtd")>0;
			stmt.close();
			conn.close();
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			System.out.println("Install.verifica_se_base_existe() Erro: "+e.getMessage() );
		}

		return retorno;
	}
}
