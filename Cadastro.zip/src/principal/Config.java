package principal;

public abstract class Config 
{
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; 
	public static final String BANCO = "jdbc:mysql://localhost/";
	public static final String BASE  = "VeiculoDB";
	public static final String USER = "root";
	public static final String PASS = "root123";
}
